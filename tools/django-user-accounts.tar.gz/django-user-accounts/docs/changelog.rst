.. _changelog:

CHANGELOG
=========

1.0
---

* initial release
* if migrating from Pinax; see :ref:`migration`
