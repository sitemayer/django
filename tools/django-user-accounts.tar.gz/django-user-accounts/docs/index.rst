====================
django-user-accounts
====================

Provides user accounts to a Django project.

Development
-----------

The source repository can be found at https://github.com/pinax/django-user-accounts/


Contents
========

.. toctree::
 :maxdepth: 2

 installation
 usage
 settings
 templates
 signals
 changelog
 migration
 faq
